package com.paypal.bfs.test.employeeserv.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.paypal.bfs.test.employeeserv.serializer.DateDeSerializer;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "employee")
@JsonInclude(Include.NON_NULL)
@ToString
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	private int id;

	@NotBlank(message = "First Name is mandatory")
	@Column(name = "first_name")
	private String firstName;

	@NotBlank(message = "Last Name is mandatory")
	@Column(name = "last_name")
	private String lastName;

	@NotNull(message = "Date is mandatory")
	@JsonDeserialize(using = DateDeSerializer.class)
	@Column(name = "date_of_birth")
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "IST")
	private Date dateOfBirth;

	@JsonManagedReference
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "address_id", referencedColumnName = "id")
	private Address address;

}
