package com.paypal.bfs.test.employeeserv.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "address")
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "native")
	private int id;

	@NotBlank(message = "Address Line1 is mandatory")
	@Column(name = "line1")
	private String line1;

	@Column(name = "line2")
	private String line2;

	@NotBlank(message = "Address City is mandatory")
	@Column(name = "city")
	private String city;

	@NotBlank(message = "Address State is mandatory")
	@Column(name = "state")
	private String state;

	@NotBlank(message = "Address Country is mandatory")
	@Column(name = "country")
	private String country;

	@NotNull(message = "Address Zip Code is mandatory")
	@Column(name = "zip_code")
	private Integer zipCode;

	@JsonBackReference
	@OneToOne(mappedBy = "address")
	private Employee employee;

	public Address(int id, @NotBlank(message = "Address Line1 is mandatory") String line1, String line2,
			@NotBlank(message = "Address City is mandatory") String city,
			@NotBlank(message = "Address State is mandatory") String state,
			@NotBlank(message = "Address Country is mandatory") String country,
			@NotNull(message = "Address Zip Code is mandatory") Integer zipCode) {
		super();
		this.id = id;
		this.line1 = line1;
		this.line2 = line2;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zipCode = zipCode;
	}

}
