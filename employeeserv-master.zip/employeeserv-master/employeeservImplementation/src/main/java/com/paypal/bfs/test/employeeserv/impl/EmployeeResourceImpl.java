package com.paypal.bfs.test.employeeserv.impl;

import java.util.List;
import java.util.NoSuchElementException;

import javax.validation.Valid;

import com.paypal.bfs.test.employeeserv.api.EmployeeResource;
import com.paypal.bfs.test.employeeserv.dao.EmployeeRepository;
import com.paypal.bfs.test.employeeserv.model.Address;
import com.paypal.bfs.test.employeeserv.model.Employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

/**
 * Implementation class for employee resource.
 */
@RestController
@CrossOrigin
public class EmployeeResourceImpl implements EmployeeResource {

    @Autowired
    EmployeeRepository employeeRepository;

    @Override
    public ResponseEntity<Employee> employeeGetById(Integer id) {
        try {
            Employee employee = employeeRepository.findById(id).get();
            return new ResponseEntity<>(employee, HttpStatus.OK);
        } catch (NoSuchElementException noSuchElementException) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException iArgumentException) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

    }

    @Override
    public ResponseEntity<List<Employee>> getAllEmployees() {
        try {
            List<Employee> employees = employeeRepository.findAll();
            if (employees == null || employees.isEmpty()) {
                throw new NoSuchElementException();
            }
            return new ResponseEntity<>(employees, HttpStatus.OK);
        } catch (NoSuchElementException noSuchElementException) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

    @Override
    public ResponseEntity<Employee> updateEmployee(Integer id, Employee employee) {
    	
    	Employee resultEmployee = null;
        employee.setId(id);
        try {
            Employee employeeDTO = employeeRepository.findById(id).get();
            if (employeeDTO != null) {
                Address address = employee.getAddress();
                Address addressDTO = employeeDTO.getAddress();
                if (addressDTO == null) {
                    addressDTO = new Address();
                }
                // employee.
                if (!employee.getFirstName().isEmpty()) {
                    employeeDTO.setFirstName(employee.getFirstName());
                }
                if (!employee.getLastName().isEmpty()) {
                    employeeDTO.setLastName(employee.getLastName());
                }
                if (employee.getDateOfBirth() != null) {
                    employeeDTO.setDateOfBirth(employee.getDateOfBirth());
                }
                if (address != null) {
                    if (!address.getLine1().isEmpty()) {
                        addressDTO.setLine1(address.getLine1());
                    }
                    if (address.getLine2() != null && !address.getLine2().isEmpty()) {
                        addressDTO.setLine2(address.getLine2());
                    }
                    if (!address.getCity().isEmpty()) {
                        addressDTO.setCity(address.getCity());
                    }
                    if (!address.getCountry().isEmpty()) {
                        addressDTO.setCountry(address.getCountry());
                    }
                    if (address.getZipCode() == null) {
                        addressDTO.setZipCode(address.getZipCode());
                    }
                }
                employeeDTO.setAddress(addressDTO);
               resultEmployee =  employeeRepository.save(employeeDTO);
            } else {
                resultEmployee =employeeRepository.save(employee);
            }
        } catch (NoSuchElementException noSuchElementException) {
            resultEmployee = employeeRepository.save(employee);
            return new ResponseEntity<>(resultEmployee, HttpStatus.OK);
        } catch (IllegalArgumentException iArgumentException) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(resultEmployee, HttpStatus.OK);

    }

    @Override
    public ResponseEntity<Employee> createEmployees(@Valid Employee employee) {
        try {
            Employee employeeDTO = employeeRepository.save(employee);
            return new ResponseEntity<>(employeeDTO, HttpStatus.CREATED);
        } catch (IllegalArgumentException iArgumentException) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @Override
    public ResponseEntity<Employee> deleteEmployee(Integer id) {
        try {
            employeeRepository.findById(id).get();
            employeeRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (NoSuchElementException noSuchElementException) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException iArgumentException) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
