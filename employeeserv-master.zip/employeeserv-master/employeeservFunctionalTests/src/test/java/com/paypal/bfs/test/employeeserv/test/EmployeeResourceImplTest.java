package com.paypal.bfs.test.employeeserv.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.paypal.bfs.test.employeeserv.dao.EmployeeRepository;
import com.paypal.bfs.test.employeeserv.impl.EmployeeResourceImpl;
import com.paypal.bfs.test.employeeserv.model.Address;
import com.paypal.bfs.test.employeeserv.model.Employee;

public class EmployeeResourceImplTest {

	@InjectMocks
	EmployeeResourceImpl employeeResourceImpl;

	@Mock
	EmployeeRepository employeeRepository;

	Employee emp = new Employee();

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testEmployeeGetById() throws ParseException {
		String date_string = "1990-01-01";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-dd-MM");
		Date date = formatter.parse(date_string);
		Address add = new Address(1, "hello", "world", "abc", "efg", "hij", 12290);
		emp = new Employee(1, "Sumit", "Sagar", date, add);
		Mockito.when(employeeRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(emp));
		ResponseEntity<Employee> res = employeeResourceImpl.employeeGetById(1);
		assertEquals("200 OK", res.getStatusCode().toString());
	}

	/*
	 * @Test//(expected = NoSuchElementException.class) public void
	 * testEmployeeGetByIdException1() {
	 * Mockito.when(employeeRepository.findById(2)).thenThrow(Exception.class);
	 * Mockito.doThrow(new
	 * NoSuchElementException("No Element")).when(employeeRepository).findById(
	 * Mockito.anyInt()); ResponseEntity<Employee> res =
	 * employeeResourceImpl.employeeGetById(2); assertEquals("400 Bad Request",
	 * res.getStatusCode().toString()); }
	 */

	@Test
	public void testGetAllEmployees() throws ParseException {
		String date_string = "1990-01-01";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-dd-MM");
		Date date = formatter.parse(date_string);
		Address add = new Address(1, "hello", "world", "abc", "efg", "hij", 12290);
		emp = new Employee(1, "Sumit", "Sagar", date, add);
		List<Employee> empList = Arrays.asList(emp);
		Mockito.when(employeeRepository.findAll()).thenReturn(empList);
		ResponseEntity<List<Employee>> res = employeeResourceImpl.getAllEmployees();
		assertEquals("200 OK", res.getStatusCode().toString());
	}

	@Test
	public void testUpdateEmployee() throws ParseException {
		String date_string = "1990-01-01";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-dd-MM");
		Date date = formatter.parse(date_string);
		Address add = new Address(1, "hello", "world", "abc", "efg", "hij", 12290);
		emp = new Employee(1, "Sumit", "Sagar", date, add);
		Mockito.when(employeeRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(emp));
		ResponseEntity<Employee> res = employeeResourceImpl.updateEmployee(1, emp);
		assertEquals("200 OK", res.getStatusCode().toString());
	}

	@Test
	public void testDeleteEmployee() throws ParseException {
		String date_string = "1990-01-01";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-dd-MM");
		Date date = formatter.parse(date_string);
		Address add = new Address(1, "hello", "world", "abc", "efg", "hij", 12290);
		emp = new Employee(1, "Sumit", "Sagar", date, add);
		Mockito.when(employeeRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(emp));
		ResponseEntity<Employee> res = employeeResourceImpl.deleteEmployee(1);
		assertEquals("200 OK", res.getStatusCode().toString());
	}

}
